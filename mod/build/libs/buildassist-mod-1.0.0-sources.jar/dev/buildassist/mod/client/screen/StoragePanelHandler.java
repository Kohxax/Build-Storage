package dev.buildassist.mod.client.screen;

import dev.buildassist.mod.client.StorageCache;
import dev.buildassist.mod.client.StorageEntry;
import dev.buildassist.mod.network.ModMessaging;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_7923;

public class StoragePanelHandler {

    // Represents one slot in the panel: a vanilla item + its storage count
    public static class SlotEntry {
        public final class_1799 displayStack;
        public final String itemKey;
        public final long count;

        public SlotEntry(class_1799 displayStack, String itemKey, long count) {
            this.displayStack = displayStack;
            this.itemKey = itemKey;
            this.count = count;
        }

        public boolean isOwned() {
            return count > 0;
        }
    }

    private final StorageCache cache;

    public StoragePanelHandler(StorageCache cache) {
        this.cache = cache;
    }

    // Returns all items in the current creative tab, filtered by search, with count from cache.
    public List<SlotEntry> buildSlots(List<class_1799> tabItems, String searchQuery) {
        List<SlotEntry> result = new ArrayList<>();
        String lowerSearch = searchQuery == null ? "" : searchQuery.toLowerCase();

        for (class_1799 stack : tabItems) {
            if (stack.method_7960()) continue;
            class_2960 id = class_7923.field_41178.method_10221(stack.method_7909());
            String itemKey = id.toString();
            String displayName = stack.method_7964().getString().toLowerCase();

            if (!lowerSearch.isEmpty() && !displayName.contains(lowerSearch) && !itemKey.contains(lowerSearch)) {
                continue;
            }

            long count = cache.getCount(itemKey);
            result.add(new SlotEntry(stack, itemKey, count));
        }
        return result;
    }

    // Withdraw one stack from the server storage
    public void withdraw(String itemKey, int amount) {
        // Send withdraw request via plugin messaging
        // The actual packet is open_storage for now; a dedicated withdraw packet
        // will be added when the server-side supports it.
        // For Phase 3, we defer to the server's open_storage+click flow.
        // TODO: add withdraw packet in Phase 5 integration
        ModMessaging.sendWithdraw(itemKey, amount);
    }

    // Deposit the player's current held item into storage
    public void depositHeld() {
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null) return;
        class_1799 held = client.field_1724.method_6047();
        if (held.method_7960()) return;
        ModMessaging.sendDeposit(class_7923.field_41178.method_10221(held.method_7909()).toString(), held.method_7947());
    }
}
