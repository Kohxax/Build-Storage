package dev.buildassist.mod.client.render;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.class_1799;
import net.minecraft.class_332;
import net.minecraft.client.render.*;

public class GrayscaleRenderer {

    private GrayscaleRenderer() {}

    // Renders an item in grayscale by drawing a dark overlay over the slot
    public static void renderGrayscaleOverlay(class_332 context, int x, int y) {
        // Draw a semi-transparent dark overlay to simulate grayscale/disabled appearance
        context.method_25294(x, y, x + 16, y + 16, 0xAA303030);
    }

    // Draw the item normally or in grayscale depending on owned flag
    public static void renderSlot(class_332 context, class_1799 stack, int x, int y, boolean owned) {
        context.method_51427(stack, x, y);
        if (!owned) {
            renderGrayscaleOverlay(context, x, y);
        }
    }
}
