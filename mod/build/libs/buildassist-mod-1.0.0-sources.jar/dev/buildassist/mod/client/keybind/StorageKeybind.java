package dev.buildassist.mod.client.keybind;

import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

public class StorageKeybind {

    public static class_304 OPEN_CONFIG;

    public static void register() {
        OPEN_CONFIG = KeyBindingHelper.registerKeyBinding(new class_304(
            "buildassist.keybind.open_config",
            class_3675.class_307.field_1668,
            GLFW.GLFW_KEY_GRAVE_ACCENT, // backtick ` as default for config
            "buildassist.keybind.category"
        ));
    }
}
