package dev.buildassist.mod.client.screen;

import dev.buildassist.mod.client.StorageCache;
import dev.buildassist.mod.client.config.BuildAssistConfig;
import dev.buildassist.mod.client.config.PanelSide;
import dev.buildassist.mod.client.render.GrayscaleRenderer;
import dev.buildassist.mod.client.render.ItemCountRenderer;
import dev.buildassist.mod.network.ModMessaging;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1761;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_490;
import net.minecraft.class_5321;
import net.minecraft.class_7706;

public class StoragePanel {

    // Layout constants
    private static final int COLS = 9;
    private static final int VISIBLE_ROWS = 6;
    private static final int SLOT_SIZE = 18;
    private static final int PANEL_WIDTH = COLS * SLOT_SIZE + 14;
    private static final int PANEL_HEIGHT = VISIBLE_ROWS * SLOT_SIZE + 48; // tabs + search bar

    private static final int TAB_HEIGHT = 14;
    private static final int SEARCH_HEIGHT = 14;

    // Colors
    private static final int BG_COLOR       = 0xCC1A1A1A;
    private static final int BORDER_COLOR   = 0xFF555555;
    private static final int TAB_ACTIVE     = 0xCC333333;
    private static final int TAB_INACTIVE   = 0xCC222222;
    private static final int HOVER_COLOR    = 0x44FFFFFF;

    private final StorageCache cache;
    private final BuildAssistConfig config;

    private int panelX;
    private int panelY;

    private int currentTabIndex = 0;
    private int scrollOffset = 0;

    private String searchQuery = "";
    private class_342 searchField;

    private List<StoragePanelHandler.SlotEntry> currentSlots = new ArrayList<>();
    private final List<class_5321<class_1761>> tabKeys = new ArrayList<>();

    private int hoveredSlot = -1;

    public StoragePanel(class_490 inventoryScreen, BuildAssistConfig config) {
        this.cache = StorageCache.INSTANCE;
        this.config = config;
        calculatePosition(inventoryScreen);
        initTabs();
        buildSearchField();
        refreshSlots();
    }

    private void calculatePosition(class_490 screen) {
        class_310 client = class_310.method_1551();
        int sw = client.method_22683().method_4486();
        int sh = client.method_22683().method_4502();
        int invX = (sw - 176) / 2 + config.getInventoryOffsetX();
        int invY = (sh - 166) / 2 + config.getInventoryOffsetY();

        PanelSide side = config.getPanelSide();
        int baseX = switch (side) {
            case LEFT  -> invX - PANEL_WIDTH - 4 + config.getPanelOffsetX();
            case RIGHT -> invX + 176 + 4 + config.getPanelOffsetX();
            case UP    -> invX + config.getPanelOffsetX();
            case DOWN  -> invX + config.getPanelOffsetX();
        };
        int baseY = switch (side) {
            case LEFT, RIGHT -> invY + config.getPanelOffsetY();
            case UP          -> invY - PANEL_HEIGHT - 4 + config.getPanelOffsetY();
            case DOWN        -> invY + 166 + 4 + config.getPanelOffsetY();
        };
        this.panelX = baseX;
        this.panelY = baseY;
    }

    private void initTabs() {
        tabKeys.clear();
        // Add vanilla item group keys in the creative tab order
        tabKeys.add(class_7706.field_40195);
        tabKeys.add(class_7706.field_41059);
        tabKeys.add(class_7706.field_40743);
        tabKeys.add(class_7706.field_40197);
        tabKeys.add(class_7706.field_40198);
        tabKeys.add(class_7706.field_41060);
        tabKeys.add(class_7706.field_40202);
        tabKeys.add(class_7706.field_41061);
        tabKeys.add(class_7706.field_41062);
        tabKeys.add(class_7706.field_40205);
    }

    private void buildSearchField() {
        class_310 client = class_310.method_1551();
        int fieldX = panelX + 5;
        int fieldY = panelY + TAB_HEIGHT + 3;
        searchField = new class_342(client.field_1772, fieldX, fieldY, PANEL_WIDTH - 10, SEARCH_HEIGHT, class_2561.method_43470(""));
        searchField.method_1880(64);
        searchField.method_1858(false);
        searchField.method_1852(searchQuery);
        searchField.method_1863(text -> {
            searchQuery = text;
            scrollOffset = 0;
            refreshSlots();
        });
    }

    private void refreshSlots() {
        class_310 client = class_310.method_1551();
        if (client.field_1687 == null || tabKeys.isEmpty()) {
            currentSlots = new ArrayList<>();
            return;
        }

        // Collect items from the current tab
        List<class_1799> tabItems = new ArrayList<>();
        class_5321<class_1761> tabKey = tabKeys.get(currentTabIndex);
        var groups = client.field_1687.method_30349()
            .method_46759(net.minecraft.class_7924.field_44688);
        if (groups.isPresent()) {
            var group = groups.get().method_29107(tabKey);
            if (group != null) {
                tabItems.addAll(group.method_47313());
            }
        }

        StoragePanelHandler handler = new StoragePanelHandler(cache);
        currentSlots = handler.buildSlots(tabItems, searchQuery);
    }

    public void render(class_332 ctx, int mouseX, int mouseY, float delta) {
        int contentStartY = panelY + TAB_HEIGHT + SEARCH_HEIGHT + 6;

        // Background
        ctx.method_25294(panelX, panelY, panelX + PANEL_WIDTH, panelY + PANEL_HEIGHT, BG_COLOR);
        // Border
        ctx.method_49601(panelX, panelY, PANEL_WIDTH, PANEL_HEIGHT, BORDER_COLOR);

        // Tab bar
        renderTabs(ctx, mouseX, mouseY);

        // Search field background
        ctx.method_25294(panelX + 3, panelY + TAB_HEIGHT + 1, panelX + PANEL_WIDTH - 3, panelY + TAB_HEIGHT + SEARCH_HEIGHT + 3, 0xFF111111);
        searchField.method_25394(ctx, mouseX, mouseY, delta);

        // Item grid
        hoveredSlot = -1;
        int firstSlot = scrollOffset * COLS;
        for (int i = 0; i < VISIBLE_ROWS * COLS; i++) {
            int slotIndex = firstSlot + i;
            if (slotIndex >= currentSlots.size()) break;

            int col = i % COLS;
            int row = i / COLS;
            int sx = panelX + 5 + col * SLOT_SIZE;
            int sy = contentStartY + row * SLOT_SIZE;

            StoragePanelHandler.SlotEntry entry = currentSlots.get(slotIndex);

            // Hover highlight
            if (mouseX >= sx && mouseX < sx + 16 && mouseY >= sy && mouseY < sy + 16) {
                ctx.method_25294(sx, sy, sx + 16, sy + 16, HOVER_COLOR);
                hoveredSlot = slotIndex;
            }

            GrayscaleRenderer.renderSlot(ctx, entry.displayStack, sx, sy, entry.isOwned());
            if (entry.isOwned()) {
                ItemCountRenderer.render(ctx, entry.count, sx, sy);
            }
        }

        // Tooltip for hovered slot
        if (hoveredSlot >= 0 && hoveredSlot < currentSlots.size()) {
            StoragePanelHandler.SlotEntry entry = currentSlots.get(hoveredSlot);
            List<class_2561> tooltip = new ArrayList<>();
            tooltip.add(entry.displayStack.method_7964());
            if (entry.isOwned()) {
                tooltip.add(class_2561.method_43470("§7在庫: §e" + ItemCountRenderer.format(entry.count)));
            } else {
                tooltip.add(class_2561.method_43470("§8未所持"));
            }
            ctx.method_51434(class_310.method_1551().field_1772, tooltip, mouseX, mouseY);
        }

        // Scrollbar
        renderScrollbar(ctx, contentStartY);
    }

    private void renderTabs(class_332 ctx, int mouseX, int mouseY) {
        int tabWidth = PANEL_WIDTH / tabKeys.size();
        for (int i = 0; i < tabKeys.size(); i++) {
            int tx = panelX + i * tabWidth;
            int color = (i == currentTabIndex) ? TAB_ACTIVE : TAB_INACTIVE;
            ctx.method_25294(tx, panelY, tx + tabWidth - 1, panelY + TAB_HEIGHT, color);
            // Tab number label (tab icons would need texture rendering)
            String label = String.valueOf(i + 1);
            class_327 font = class_310.method_1551().field_1772;
            ctx.method_51433(font, label, tx + tabWidth / 2 - font.method_1727(label) / 2, panelY + 3, 0xFFAAAAAA, false);
        }
    }

    private void renderScrollbar(class_332 ctx, int contentStartY) {
        int totalRows = (int) Math.ceil((double) currentSlots.size() / COLS);
        if (totalRows <= VISIBLE_ROWS) return;

        int barX = panelX + PANEL_WIDTH - 6;
        int barAreaHeight = VISIBLE_ROWS * SLOT_SIZE;
        int barHeight = Math.max(10, barAreaHeight * VISIBLE_ROWS / totalRows);
        int barY = contentStartY + (barAreaHeight - barHeight) * scrollOffset / Math.max(1, totalRows - VISIBLE_ROWS);

        ctx.method_25294(barX, contentStartY, barX + 4, contentStartY + barAreaHeight, 0xFF222222);
        ctx.method_25294(barX, barY, barX + 4, barY + barHeight, 0xFF888888);
    }

    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (searchField.method_25402(mouseX, mouseY, button)) return true;

        // Tab click
        int tabWidth = PANEL_WIDTH / tabKeys.size();
        if (mouseY >= panelY && mouseY < panelY + TAB_HEIGHT && mouseX >= panelX && mouseX < panelX + PANEL_WIDTH) {
            int idx = (int) ((mouseX - panelX) / tabWidth);
            if (idx >= 0 && idx < tabKeys.size()) {
                currentTabIndex = idx;
                scrollOffset = 0;
                refreshSlots();
                return true;
            }
        }

        // Slot click
        if (hoveredSlot >= 0 && hoveredSlot < currentSlots.size()) {
            StoragePanelHandler.SlotEntry entry = currentSlots.get(hoveredSlot);
            if (entry.isOwned()) {
                int amount = switch (button) {
                    case 0 -> entry.displayStack.method_7909().method_7882(); // left: full stack
                    case 1 -> Math.max(1, entry.displayStack.method_7909().method_7882() / 2); // right: half
                    default -> 1;
                };
                ModMessaging.sendWithdraw(entry.itemKey, (int) Math.min(amount, entry.count));
            }
            return true;
        }

        return false;
    }

    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        int contentStartY = panelY + TAB_HEIGHT + SEARCH_HEIGHT + 6;
        int contentEndY = contentStartY + VISIBLE_ROWS * SLOT_SIZE;
        if (mouseX < panelX || mouseX > panelX + PANEL_WIDTH || mouseY < contentStartY || mouseY > contentEndY) {
            return false;
        }
        int totalRows = (int) Math.ceil((double) currentSlots.size() / COLS);
        scrollOffset = Math.max(0, Math.min(scrollOffset - (int) Math.signum(verticalAmount), totalRows - VISIBLE_ROWS));
        return true;
    }

    public boolean charTyped(char chr, int modifiers) {
        return searchField.method_25400(chr, modifiers);
    }

    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        return searchField.method_25404(keyCode, scanCode, modifiers);
    }

    public void onStorageUpdate() {
        refreshSlots();
    }
}
