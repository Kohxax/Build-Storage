package dev.buildassist.mod.client.render;

import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;

public class ItemCountRenderer {

    private ItemCountRenderer() {}

    public static void render(class_332 context, long count, int x, int y) {
        if (count <= 0) return;
        String label = format(count);
        class_327 font = class_310.method_1551().field_1772;
        int textX = x + 16 - font.method_1727(label);
        int textY = y + 16 - font.field_2000 + 1;
        // Shadow then text for readability
        context.method_51433(font, label, textX + 1, textY + 1, 0xFF000000, false);
        context.method_51433(font, label, textX, textY, 0xFFFFFFFF, false);
    }

    public static String format(long count) {
        if (count >= 1_000_000) {
            long m = count / 100_000;
            return (m / 10) + (m % 10 == 0 ? "" : "." + (m % 10)) + "m";
        }
        if (count >= 1_000) {
            long k = count / 100;
            return (k / 10) + (k % 10 == 0 ? "" : "." + (k % 10)) + "k";
        }
        return String.valueOf(count);
    }
}
