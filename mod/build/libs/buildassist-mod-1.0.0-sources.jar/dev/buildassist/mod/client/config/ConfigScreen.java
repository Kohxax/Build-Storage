package dev.buildassist.mod.client.config;

import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class ConfigScreen extends class_437 {

    private static final int BUTTON_W = 100;
    private static final int BUTTON_H = 20;
    private static final int SPACING = 6;

    private final class_437 parent;
    private final BuildAssistConfig config;

    // Drag state for panel position adjustment
    private boolean draggingPanel = false;
    private boolean draggingInventory = false;
    private double dragStartX, dragStartY;
    private int dragBaseX, dragBaseY;

    public ConfigScreen(class_437 parent) {
        super(class_2561.method_43471("buildassist.screen.config.title"));
        this.parent = parent;
        this.config = BuildAssistConfig.get();
    }

    @Override
    protected void method_25426() {
        int cx = field_22789 / 2;
        int cy = field_22790 / 2;

        // Panel side buttons
        int y = cy - 80;
        method_37063(class_4185.method_46430(sideLabel(PanelSide.LEFT), b -> setSide(PanelSide.LEFT))
            .method_46434(cx - BUTTON_W - SPACING / 2, y, BUTTON_W, BUTTON_H).method_46431());
        method_37063(class_4185.method_46430(sideLabel(PanelSide.RIGHT), b -> setSide(PanelSide.RIGHT))
            .method_46434(cx + SPACING / 2, y, BUTTON_W, BUTTON_H).method_46431());
        method_37063(class_4185.method_46430(sideLabel(PanelSide.UP), b -> setSide(PanelSide.UP))
            .method_46434(cx - BUTTON_W / 2, y + BUTTON_H + SPACING, BUTTON_W, BUTTON_H).method_46431());
        method_37063(class_4185.method_46430(sideLabel(PanelSide.DOWN), b -> setSide(PanelSide.DOWN))
            .method_46434(cx - BUTTON_W / 2, y + (BUTTON_H + SPACING) * 2, BUTTON_W, BUTTON_H).method_46431());

        // Offset nudge buttons for panel
        int nudgeY = cy + 20;
        method_37063(class_4185.method_46430(class_2561.method_43470("Panel ←"), b -> nudgePanel(-4, 0))
            .method_46434(cx - 160, nudgeY, 70, BUTTON_H).method_46431());
        method_37063(class_4185.method_46430(class_2561.method_43470("Panel →"), b -> nudgePanel(4, 0))
            .method_46434(cx - 84, nudgeY, 70, BUTTON_H).method_46431());
        method_37063(class_4185.method_46430(class_2561.method_43470("Panel ↑"), b -> nudgePanel(0, -4))
            .method_46434(cx - 160, nudgeY + BUTTON_H + SPACING, 70, BUTTON_H).method_46431());
        method_37063(class_4185.method_46430(class_2561.method_43470("Panel ↓"), b -> nudgePanel(0, 4))
            .method_46434(cx - 84, nudgeY + BUTTON_H + SPACING, 70, BUTTON_H).method_46431());

        // Offset nudge buttons for inventory
        method_37063(class_4185.method_46430(class_2561.method_43470("Inv ←"), b -> nudgeInventory(-4, 0))
            .method_46434(cx + 14, nudgeY, 70, BUTTON_H).method_46431());
        method_37063(class_4185.method_46430(class_2561.method_43470("Inv →"), b -> nudgeInventory(4, 0))
            .method_46434(cx + 90, nudgeY, 70, BUTTON_H).method_46431());
        method_37063(class_4185.method_46430(class_2561.method_43470("Inv ↑"), b -> nudgeInventory(0, -4))
            .method_46434(cx + 14, nudgeY + BUTTON_H + SPACING, 70, BUTTON_H).method_46431());
        method_37063(class_4185.method_46430(class_2561.method_43470("Inv ↓"), b -> nudgeInventory(0, 4))
            .method_46434(cx + 90, nudgeY + BUTTON_H + SPACING, 70, BUTTON_H).method_46431());

        // Reset & Done
        method_37063(class_4185.method_46430(class_2561.method_43470("リセット"), b -> resetOffsets())
            .method_46434(cx - 50, cy + 90, BUTTON_W, BUTTON_H).method_46431());
        method_37063(class_4185.method_46430(class_2561.method_43470("完了"), b -> method_25419())
            .method_46434(cx - 50, cy + 90 + BUTTON_H + SPACING, BUTTON_W, BUTTON_H).method_46431());
    }

    @Override
    public void method_25394(class_332 ctx, int mouseX, int mouseY, float delta) {
        method_25420(ctx, mouseX, mouseY, delta);
        ctx.method_27534(field_22793, field_22785, field_22789 / 2, 20, 0xFFFFFF);

        // Current settings info
        String info = String.format("Side: %s  Panel offset: (%d, %d)  Inv offset: (%d, %d)",
            config.getPanelSide(),
            config.getPanelOffsetX(), config.getPanelOffsetY(),
            config.getInventoryOffsetX(), config.getInventoryOffsetY());
        ctx.method_25300(field_22793, info, field_22789 / 2, field_22790 / 2 - 100, 0xAAAAAA);

        ctx.method_25300(field_22793, "← パネル位置 →     ← インベントリ位置 →", field_22789 / 2, field_22790 / 2 + 14, 0xAAAAAA);

        super.method_25394(ctx, mouseX, mouseY, delta);
    }

    @Override
    public void method_25419() {
        config.save();
        field_22787.method_1507(parent);
    }

    private class_2561 sideLabel(PanelSide side) {
        String arrow = switch (side) {
            case LEFT -> "◀ 左";
            case RIGHT -> "右 ▶";
            case UP -> "▲ 上";
            case DOWN -> "▼ 下";
        };
        boolean active = config.getPanelSide() == side;
        return class_2561.method_43470((active ? "§e" : "§7") + arrow);
    }

    private void setSide(PanelSide side) {
        config.setPanelSide(side);
        config.save();
        method_41843();
    }

    private void nudgePanel(int dx, int dy) {
        config.setPanelOffsetX(config.getPanelOffsetX() + dx);
        config.setPanelOffsetY(config.getPanelOffsetY() + dy);
        config.save();
    }

    private void nudgeInventory(int dx, int dy) {
        config.setInventoryOffsetX(config.getInventoryOffsetX() + dx);
        config.setInventoryOffsetY(config.getInventoryOffsetY() + dy);
        config.save();
    }

    private void resetOffsets() {
        config.setPanelOffsetX(0);
        config.setPanelOffsetY(0);
        config.setInventoryOffsetX(0);
        config.setInventoryOffsetY(0);
        config.save();
    }

    @Override
    public boolean method_25421() { return false; }
}
