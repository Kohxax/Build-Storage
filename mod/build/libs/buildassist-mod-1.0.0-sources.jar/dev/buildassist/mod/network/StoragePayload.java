package dev.buildassist.mod.network;

import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9139;

public record StoragePayload(byte[] data) implements class_8710 {

    public static final class_9154<StoragePayload> ID = new class_9154<>(class_2960.method_60655("buildassist", "main"));

    public static final class_9139<class_2540, StoragePayload> CODEC = class_9139.method_56438(
        (value, buf) -> buf.method_52983(value.data()),
        buf -> {
            byte[] bytes = new byte[buf.readableBytes()];
            buf.method_52979(bytes);
            return new StoragePayload(bytes);
        }
    );

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return ID;
    }
}
